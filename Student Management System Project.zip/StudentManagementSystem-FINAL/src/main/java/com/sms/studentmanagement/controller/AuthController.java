package com.sms.studentmanagement.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AuthController {

    @GetMapping("/login")
    public String showLoginPage() {
        return "login";  // maps to login.html under templates
    }

    @GetMapping("/signup")
    public String showSignupPage() {
        return "signup";  // maps to signup.html under templates
    }
}
