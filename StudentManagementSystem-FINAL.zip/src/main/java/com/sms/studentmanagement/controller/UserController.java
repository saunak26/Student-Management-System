package com.sms.studentmanagement.controller;

import com.sms.studentmanagement.model.User;
import com.sms.studentmanagement.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")
public class UserController {
    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public User register(@RequestBody User user) {
        return userService.registerUser(user);
    }

    @PostMapping("/login")
    public boolean login(@RequestBody User user) {
        return userService.login(user.getUsername(), user.getPassword());
    }
}